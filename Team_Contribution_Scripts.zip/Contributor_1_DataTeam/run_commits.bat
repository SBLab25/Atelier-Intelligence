@echo off
echo Starting Git Commit sequence for Data Backend...

git checkout -b feature/data-tracker-updates

:: Commit 1: Minor tools
git add cji_agent/tools/ingest_json.py
git add cji_agent/tests/test_synthetic_data.py
git commit -m "Initialize data ingestion and test scripts"

:: Commit 2: Empty dummy commit for "activity"
git commit --allow-empty -m "WIP: Experimenting with new tracking schemas"

:: Commit 3: Revert dummy commit and add synthetic data
git add cji_agent/tools/synthetic_data.py
git commit -m "Revert schema experiment and finalize synthetic data engine"

:: Commit 4: Add tracker script
git add cji_agent/tracker/tracker.js
git commit -m "Update tracking JavaScript snippet with accurate payload mapping"

:: Commit 5: Add API and Server
git add cji_agent/collector/api.py
git add cji_agent/mcp_servers/journey_data_server.py
git commit -m "Refactor collector API and connect Journey MCP servers"

echo.
echo ========================================================
echo All commits created successfully.
echo To push your changes to GitHub, run:
echo git push -u origin feature/data-tracker-updates
echo ========================================================
pause
