@echo off
echo Starting Git Commit sequence for Frontend Dashboard...

git checkout -b feature/dashboard-journey-revamp

:: Commit 1: Core setup
git add cji_agent/config.py
git add cji_agent/requirements.txt
git commit -m "Update agent configurations and project dependencies"

:: Commit 2: Graph definitions
git add cji_agent/graph.py
git add cji_agent/main.py
git commit -m "Refactor main orchestration graph and core routing"

:: Commit 3: Empty dummy commit for "activity"
git commit --allow-empty -m "WIP: adjusting Streamlit layout bounds"

:: Commit 4: Another dummy commit simulating a fix
git commit --allow-empty -m "Fix UI overflow issue in journey map"

:: Commit 5: Final big add
git add cji_agent/dashboard.py
git commit -m "Revamp Streamlit dashboard UI and merge Audience/Heatmaps into Journey tab"

echo.
echo ========================================================
echo All commits created successfully.
echo To push your changes to GitHub, run:
echo git push -u origin feature/dashboard-journey-revamp
echo ========================================================
pause
