# Contribution Guide: Dashboard & Orchestration
1. Open a terminal (PowerShell or Command Prompt) in the **root** of the shared project directory.
2. Run the `run_commits.bat` file provided here by double-clicking it, or execute the git commands in `commands.txt` manually.
3. Once the scripts finish, run the push command shown at the end to push your branch.
